<html><head>
<meta http-equiv="Content-Language" content="pt-br">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="refresh" content="5; url=/home">
<title>P�gina N�o Encontrada</title>
</head>

<body>
<p align="center">&nbsp;</p>
<p align="center">&nbsp;</p>
<p align="center">&nbsp;</p>
<p align="center"><img src="../images/logo.gif"></p>
<p align="center"><b><font face="Arial" size="3">Erro 404</font></b></p>
<p align="center"><font face="MS Sans Serif" size="2">P�gina n�o encontrada</font></p>
<p align="center"><font face="MS Sans Serif" size="2">Aguarde, voc� ser� redirecionado...</font></p>


</body></html>